# AlfaGen k6 Load Suite

Готовый набор: **3 HTTP-сценария + 2 Kafka producer-сценария**. Каждый сценарий можно запускать отдельно либо все пять одновременно с выбранным профилем нагрузки.

## Структура

- `scripts/http_01_get.js` — HTTP GET.
- `scripts/http_02_post.js` — HTTP POST с JSON.
- `scripts/http_03_post.js` — HTTP POST с JSON.
- `scripts/kafka_01_events.js` — Kafka event producer в `KAFKA_TOPIC_1`.
- `scripts/kafka_02_transactions.js` — Kafka transaction producer в `KAFKA_TOPIC_2`.
- `all.js` — параллельный запуск пяти сценариев.
- `lib/profiles.js` — профили и настройки arrival-rate.
- `lib/kafka.js` — Kafka brokers, SASL и TLS.
- `run.ps1`, `run.sh` — выбор сценария и профиля из командной строки.

## Требования и сборка

Нужен k6 с расширением `k6/x/kafka`. В проекте закреплена ранее используемая связка: k6 `v1.8.2`, xk6 `v1.4.14`, `grafana/xk6-kafka` `v0.1.0`.

Если свой бинарник уже собран, пропустите сборку. Иначе:
- Windows: `.\build-k6.ps1`
- Linux/macOS: `chmod +x build-k6.sh run.sh && ./build-k6.sh`

Нужны Go и доступ к Go module proxy. Бинарник k6 должен быть в PATH либо в текущем каталоге (в последнем случае добавьте его в PATH).

## Запуск

PowerShell:
```powershell
.\run.ps1 -Target http1 -Profile smoke
.\run.ps1 -Target http2 -Profile load
.\run.ps1 -Target http3 -Profile stress
.\run.ps1 -Target kafka1 -Profile smoke
.\run.ps1 -Target kafka2 -Profile load
.\run.ps1 -Target all -Profile load
```

Linux/macOS:
```bash
./run.sh --target http1 --profile smoke
./run.sh --target kafka1 --profile smoke
./run.sh --target all --profile stress
```

`Target`: `http1`, `http2`, `http3`, `kafka1`, `kafka2`, `all`.
`Profile`: `smoke`, `load`, `stress`.

Профили задают **итерации/сек на один сценарий** при одиночном запуске:
- `smoke`: 30 секунд, ramp до 5 итераций/сек.
- `load`: ramp до 25, затем до 100 итераций/сек и удержание; около 4 минут.
- `stress`: ramp до 100, затем до 250 итераций/сек и удержание; около 5 минут.

При `Target=all` интенсивность каждого сценария делится примерно на пять, чтобы целевая общая интенсивность соответствовала профилю. Одна итерация HTTP = один запрос; одна итерация Kafka = одно сообщение. Если k6 не хватает VU, появится `dropped_iterations`: увеличьте `preAllocatedVUs`/`maxVUs` в `lib/profiles.js` и проверьте CPU/RAM генератора.

## HTTP endpoints

По умолчанию используются демонстрационные URL:
- `http://localhost:8080/mock/http-01`
- `http://localhost:8080/mock/http-02`
- `http://localhost:8080/mock/http-03`

Задайте реальные URL или локальные WireMock mappings перед запуском:

PowerShell:
```powershell
$env:HTTP_URL_1 = "http://localhost:8080/mock/http-01"
$env:HTTP_URL_2 = "http://localhost:8080/mock/http-02"
$env:HTTP_URL_3 = "http://localhost:8080/mock/http-03"
$env:HTTP_TIMEOUT = "90s"
$env:HTTP_PAYLOAD_2 = '{"operationId":"test-123","amount":100,"currency":"RUB"}'
$env:HTTP_PAYLOAD_3 = '{"eventType":"test","source":"k6"}'
.\run.ps1 -Target all -Profile smoke
```

`HTTP_PAYLOAD_2` и `HTTP_PAYLOAD_3` позволяют заменить тестовые JSON-тела.

## Kafka: brokers, topic-per-script, SASL и TLS

Задайте адреса брокеров и разные топики:
```powershell
$env:KAFKA_BROKERS = "broker1:9092,broker2:9092"
$env:KAFKA_TOPIC_1 = "alfagen.events.loadtest"
$env:KAFKA_TOPIC_2 = "alfagen.transactions.loadtest"
```

Каждый Kafka-скрипт создаёт собственный `Writer`, настроенный на свой топик; сообщение не маршрутизируется в общий топик.

Без SASL:
```powershell
$env:KAFKA_SASL_MECHANISM = "NONE"
$env:KAFKA_TLS = "false"
.\run.ps1 -Target kafka1 -Profile smoke
```

SASL PLAIN:
```powershell
$env:KAFKA_SASL_MECHANISM = "PLAIN"
$env:KAFKA_SASL_USERNAME = "load_user"
$env:KAFKA_SASL_PASSWORD = "<secret>"
$env:KAFKA_TLS = "false"
.\run.ps1 -Target all -Profile load
```

SASL SCRAM-SHA-256:
```powershell
$env:KAFKA_SASL_MECHANISM = "SCRAM-SHA-256"
$env:KAFKA_SASL_USERNAME = "load_user"
$env:KAFKA_SASL_PASSWORD = "<secret>"
$env:KAFKA_TLS = "false"
.\run.ps1 -Target kafka2 -Profile smoke
```

SASL SCRAM-SHA-512 + TLS (SASL_SSL):
```powershell
$env:KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
$env:KAFKA_SASL_USERNAME = "load_user"
$env:KAFKA_SASL_PASSWORD = "<secret>"
$env:KAFKA_TLS = "true"
$env:KAFKA_CA_FILE = "C:\certs\kafka-ca.pem"
.\run.ps1 -Target all -Profile load
```

Поддерживаемые значения механизма: `NONE`, `PLAIN`, `SCRAM-SHA-256`, `SCRAM-SHA-512`. Для SASL_SSL включите `KAFKA_TLS=true` вместе с выбранным механизмом. Расширение использует отдельные настройки SASL и TLS. CA PEM и клиентские PEM-файлы загружаются через `open()` по указанным путям. Для mTLS задайте оба `KAFKA_CLIENT_CERT_FILE` и `KAFKA_CLIENT_KEY_FILE`.

`KAFKA_TLS_SKIP_VERIFY=true` допускается только для временной диагностики, не для штатного прогона. Не записывайте реальные пароли в репозиторий и не передавайте их аргументами командной строки — используйте переменные окружения/секреты CI.

Дополнительные настройки:
```powershell
$env:KAFKA_AUTO_CREATE_TOPIC = "false"
$env:KAFKA_REQUIRED_ACKS = "1"
$env:KAFKA_WRITE_TIMEOUT_MS = "10000"
$env:TEST_RUN_ID = "alfagen-perf-001"
```

Топики рекомендуется создавать заранее и оставить `KAFKA_AUTO_CREATE_TOPIC=false`, чтобы операции создания топиков не влияли на результаты. `KAFKA_REQUIRED_ACKS` принимает `-1`, `0` или `1`; выберите значение, соответствующее цели теста и политике подтверждений кластера.

## Метрики

HTTP: `http_reqs`, `http_req_duration`, `http_req_failed`, `checks`, `dropped_iterations`.
Kafka: `kafka_writer_message_count`, `kafka_writer_error_count`, `kafka_writer_message_bytes`, `kafka_writer_write_seconds`.

Thresholds по умолчанию: HTTP error rate < 1%, checks > 99%, Kafka writer errors = 0. Настройте их под согласованные NFR/SLA.

## Замечания

- `grafana/xk6-kafka` v0.1.0 — pre-1.0 API; при обновлении расширения проверьте совместимость.
- `Writer.produce()` в используемом API блокируется до подтверждения отправки; реальный throughput зависит от ack, брокеров, сети, размера сообщения и числа VU.
- Не путайте RPS HTTP и messages/sec Kafka: сценарии используют отдельные итерации и отдельные метрики.
- Проверяйте CPU/RAM генератора, `dropped_iterations`, ошибки авторизации, latency и Kafka broker metrics.
- Скрипты используют демонстрационные тела сообщений и endpoint'ы. Перед тестом замените URL, payload и топики на соответствующие контрактам AlfaGen.

## Документация

- https://github.com/grafana/xk6-kafka
- https://pkg.go.dev/github.com/grafana/xk6-kafka@v0.1.0/pkg/kafka
- https://grafana.com/docs/k6/latest/using-k6/scenarios/

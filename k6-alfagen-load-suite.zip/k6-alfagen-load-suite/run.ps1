param(
  [ValidateSet("http1","http2","http3","kafka1","kafka2","all")]
  [string]$Target = "all",
  [ValidateSet("smoke","load","stress")]
  [string]$Profile = "smoke"
)
$ErrorActionPreference = "Stop"
$map = @{
  http1="scripts/http_01_get.js"; http2="scripts/http_02_post.js"; http3="scripts/http_03_post.js"
  kafka1="scripts/kafka_01_events.js"; kafka2="scripts/kafka_02_transactions.js"; all="all.js"
}
$scriptPath = Join-Path $PSScriptRoot $map[$Target]
if (-not (Test-Path $scriptPath)) { throw "Script not found: $scriptPath" }

if ($env:K6_BIN) {
  $k6 = $env:K6_BIN
} elseif (Test-Path (Join-Path $PSScriptRoot "k6.exe")) {
  $k6 = Join-Path $PSScriptRoot "k6.exe"
} elseif (Test-Path (Join-Path $PSScriptRoot "k6")) {
  $k6 = Join-Path $PSScriptRoot "k6"
} else {
  $k6 = (Get-Command k6 -ErrorAction Stop).Source
}
Write-Host "Target=$Target Profile=$Profile K6=$k6"
& $k6 run --include-system-env-vars -e "PROFILE=$Profile" $scriptPath
exit $LASTEXITCODE

import { Writer } from "k6/x/kafka";
import { check } from "k6";
import { kafkaClientConfig } from "../lib/kafka.js";
import { singleScenarioOptions } from "../lib/profiles.js";
export const options = singleScenarioOptions("kafka02");
const topic = __ENV.KAFKA_TOPIC_2 || "alfagen.transactions.loadtest";
const writer = new Writer(kafkaClientConfig(topic));
export function kafka02() {
  const message = { transactionId: `txn-${__VU}-${__ITER}`, operation: "PAYMENT",
    amount: 100, currency: "RUB", status: "CREATED", createdAt: new Date().toISOString(),
    metadata: { source: "k6", vu: __VU, iteration: __ITER, testRun: __ENV.TEST_RUN_ID || "local" } };
  writer.produce({ messages: [{ key: message.transactionId, value: JSON.stringify(message) }] });
  check(message, { "kafka02 transaction object valid": (m) => Boolean(message.transactionId && message.amount > 0) });
}
export default function () { kafka02(); }
export function closeKafka02() { writer.close(); }
export function teardown() { writer.close(); }

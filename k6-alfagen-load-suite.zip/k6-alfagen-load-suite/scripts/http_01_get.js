import http from "k6/http";
import { check } from "k6";
import { singleScenarioOptions } from "../lib/profiles.js";
export const options = singleScenarioOptions("http01");
const URL = __ENV.HTTP_URL_1 || "http://localhost:8080/mock/http-01";
export function http01() {
  const r = http.get(URL, { tags: { scenario: "http01", endpoint: "http-01" }, timeout: __ENV.HTTP_TIMEOUT || "90s" });
  check(r, { "http01 status is 2xx": x => x.status >= 200 && x.status < 300 });
}
export default function () { http01(); }

import http from "k6/http";
import { check } from "k6";
import { singleScenarioOptions } from "../lib/profiles.js";
export const options = singleScenarioOptions("http03");
const URL = __ENV.HTTP_URL_3 || "http://localhost:8080/mock/http-03";
const BODY = __ENV.HTTP_PAYLOAD_3 || JSON.stringify({ eventType: "alfagen.loadtest", source: "k6", payload: { eventId: "load-test-event", test: true } });
export function http03() {
  const r = http.post(URL, BODY, { headers: { "Content-Type": "application/json" }, tags: { scenario: "http03", endpoint: "http-03" }, timeout: __ENV.HTTP_TIMEOUT || "90s" });
  check(r, { "http03 status is 2xx": x => x.status >= 200 && x.status < 300 });
}
export default function () { http03(); }

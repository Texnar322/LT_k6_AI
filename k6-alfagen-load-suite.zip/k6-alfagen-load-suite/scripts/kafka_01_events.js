import { Writer } from "k6/x/kafka";
import { check } from "k6";
import { kafkaClientConfig } from "../lib/kafka.js";
import { singleScenarioOptions } from "../lib/profiles.js";
export const options = singleScenarioOptions("kafka01");
const topic = __ENV.KAFKA_TOPIC_1 || "alfagen.events.loadtest";
const writer = new Writer(kafkaClientConfig(topic));
export function kafka01() {
  const message = { messageId: `event-${__VU}-${__ITER}`, eventType: "ALFAGEN_LOAD_TEST",
    source: "k6", createdAt: new Date().toISOString(),
    payload: { vu: __VU, iteration: __ITER, testRun: __ENV.TEST_RUN_ID || "local" } };
  writer.produce({ messages: [{ key: message.messageId, value: JSON.stringify(message) }] });
  check(message, { "kafka01 message object valid": (m) => Boolean(message.messageId && message.eventType) });
}
export default function () { kafka01(); }
export function closeKafka01() { writer.close(); }
export function teardown() { writer.close(); }

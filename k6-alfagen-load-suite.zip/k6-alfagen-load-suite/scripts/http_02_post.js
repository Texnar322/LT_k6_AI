import http from "k6/http";
import { check } from "k6";
import { singleScenarioOptions } from "../lib/profiles.js";
export const options = singleScenarioOptions("http02");
const URL = __ENV.HTTP_URL_2 || "http://localhost:8080/mock/http-02";
const BODY = __ENV.HTTP_PAYLOAD_2 || JSON.stringify({ operationId: "k6-load-test", amount: 100, currency: "RUB" });
export function http02() {
  const r = http.post(URL, BODY, { headers: { "Content-Type": "application/json" }, tags: { scenario: "http02", endpoint: "http-02" }, timeout: __ENV.HTTP_TIMEOUT || "90s" });
  check(r, { "http02 status is 2xx": x => x.status >= 200 && x.status < 300 });
}
export default function () { http02(); }

import { allScenarioOptions } from "./lib/profiles.js";
import { http01 as runHttp01 } from "./scripts/http_01_get.js";
import { http02 as runHttp02 } from "./scripts/http_02_post.js";
import { http03 as runHttp03 } from "./scripts/http_03_post.js";
import { kafka01 as runKafka01, closeKafka01 } from "./scripts/kafka_01_events.js";
import { kafka02 as runKafka02, closeKafka02 } from "./scripts/kafka_02_transactions.js";
export const options = allScenarioOptions();
export function http01() { runHttp01(); }
export function http02() { runHttp02(); }
export function http03() { runHttp03(); }
export function kafka01() { runKafka01(); }
export function kafka02() { runKafka02(); }
export function teardown() { closeKafka01(); closeKafka02(); }

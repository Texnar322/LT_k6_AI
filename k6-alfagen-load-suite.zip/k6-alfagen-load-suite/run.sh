#!/usr/bin/env bash
set -euo pipefail
TARGET="all"; PROFILE="smoke"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET="$2"; shift 2 ;;
    --profile) PROFILE="$2"; shift 2 ;;
    -h|--help) echo "Usage: ./run.sh --target http1|http2|http3|kafka1|kafka2|all --profile smoke|load|stress"; exit 0 ;;
    *) echo "Unknown argument: $1"; exit 2 ;;
  esac
done
case "$TARGET" in
  http1) SCRIPT="scripts/http_01_get.js" ;;
  http2) SCRIPT="scripts/http_02_post.js" ;;
  http3) SCRIPT="scripts/http_03_post.js" ;;
  kafka1) SCRIPT="scripts/kafka_01_events.js" ;;
  kafka2) SCRIPT="scripts/kafka_02_transactions.js" ;;
  all) SCRIPT="all.js" ;;
  *) echo "Invalid target: $TARGET"; exit 2 ;;
esac
case "$PROFILE" in smoke|load|stress) ;; *) echo "Invalid profile: $PROFILE"; exit 2 ;; esac
if [[ -n "${K6_BIN:-}" ]]; then
  K6="$K6_BIN"
elif [[ -x "./k6" ]]; then
  K6="./k6"
else
  K6="$(command -v k6)"
fi
echo "Target=$TARGET Profile=$PROFILE K6=$K6"
"$K6" run --include-system-env-vars -e "PROFILE=$PROFILE" "$SCRIPT"

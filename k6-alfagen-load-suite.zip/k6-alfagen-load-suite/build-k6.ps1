param(
  [string]$K6Version = "v1.8.2",
  [string]$XK6Version = "v1.4.14",
  [string]$KafkaExtensionVersion = "v0.1.0"
)
$ErrorActionPreference = "Stop"
$env:CGO_ENABLED = "0"
go version
go install "go.k6.io/xk6/cmd/xk6@$XK6Version"
$xk6 = Join-Path (go env GOPATH) "bin/xk6.exe"
if (-not (Test-Path $xk6)) { $xk6 = "xk6" }
& $xk6 build $K6Version --with "github.com/grafana/xk6-kafka@$KafkaExtensionVersion"
if ($LASTEXITCODE -ne 0) { throw "xk6 build failed: $LASTEXITCODE" }
Write-Host "Built ./k6.exe with grafana/xk6-kafka@$KafkaExtensionVersion"
